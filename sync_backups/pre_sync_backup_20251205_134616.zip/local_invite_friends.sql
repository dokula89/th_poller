-- LOCAL DATABASE: invite_friends
CREATE TABLE `invite_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `friend_to_be_invited_email` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `invite_friends` (`id`,`friend_to_be_invited_email`,`time`,`user_id`,`ip`) VALUES (1,'dokula@gmail.com',1719002167,4,'67.168.61.169');
INSERT IGNORE INTO `invite_friends` (`id`,`friend_to_be_invited_email`,`time`,`user_id`,`ip`) VALUES (2,'dokula1@gmail.com',1719686480,4,'73.118.143.233');
