-- REMOTE DATABASE: apartment_listings_price_changes
CREATE TABLE `apartment_listings_price_changes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `apartment_listings_id` int NOT NULL,
  `new_price` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date GENERATED ALWAYS AS (cast(`time` as date)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index` (`apartment_listings_id`,`new_price`,`time`),
  UNIQUE KEY `unique_apartment_date` (`apartment_listings_id`,`date`),
  CONSTRAINT `apartment_listings_price_changes_ibfk_1` FOREIGN KEY (`apartment_listings_id`) REFERENCES `apartment_listings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=584 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (100,4,'2600','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (92,18,'1695','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (93,21,'2450','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (94,23,'1895','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (95,25,'1295','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (96,36,'2450','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (97,40,'2150','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (98,47,'1500','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (99,49,'2550','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (102,53,'1795','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (103,54,'1325','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (4,54,'1395','2025-11-14 05:19:16');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (1,68,'1550','2025-11-11 17:23:04');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (5,68,'1550','2025-11-14 05:19:17');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (110,68,'1550','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (104,72,'1150','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (105,81,'1350','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (106,83,'1595','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (107,91,'3100','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (108,114,'1695','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (109,115,'1250','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (111,125,'1095','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (112,139,'2900','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (113,144,'1125','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (114,146,'995','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (115,151,'1425','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (116,160,'1045','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (6,165,'1495','2025-11-14 05:19:17');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (117,165,'1495','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (7,172,'1645','2025-11-14 05:19:17');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (118,173,'2795','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (101,177,'1975','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (119,189,'2795','2025-11-22 17:44:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (82,243,'1125','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (83,244,'1650','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (84,249,'1395','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (2,249,'1450','2025-11-11 17:54:09');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (8,249,'1450','2025-11-14 05:22:32');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (86,252,'2425','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (87,257,'1795','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (88,262,'2295','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (89,267,'1525','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (90,280,'1125','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (3,284,'2895','2025-11-11 17:55:32');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (9,305,'1195','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (11,312,'2400','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (12,315,'1315','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (13,316,'1460','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (14,318,'1475','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (15,319,'1975','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (10,323,'1475','2025-11-22 03:51:00');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (79,329,'1395','2025-11-22 03:54:34');
INSERT IGNORE INTO `apartment_listings_price_changes` (`id`,`apartment_listings_id`,`new_price`,`time`) VALUES (91,332,'1875','2025-11-22 17:44:00');
