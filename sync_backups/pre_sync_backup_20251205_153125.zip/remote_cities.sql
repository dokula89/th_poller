-- REMOTE DATABASE: cities
CREATE TABLE `cities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metro_id` int DEFAULT NULL,
  `911_website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `metro_id` (`metro_id`),
  CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`metro_id`) REFERENCES `major_metros` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (1,'Seattle',1,'https://data.seattle.gov/Public-Safety/Call-Data/33kz-ixgy/about_data','https://data.seattle.gov/Community/Code-Complaints-and-Violations/8s4s-3hc9');
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (2,'Bellevue',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (3,'Tacoma',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (4,'Portland',2,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (5,'Vancouver',2,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (6,'San Francisco',3,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (7,'Oakland',3,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (8,'San Jose',3,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (9,'Bothell',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (10,'Shoreline',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (11,'Auburn',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (12,'Lynnwood',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (13,'Spokane',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (14,'Issaquah',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (15,'Renton',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (16,'Edmonds',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (17,'Burien',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (18,'Redmond',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (19,'Everett',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (20,'Mercer Island',1,NULL,NULL);
INSERT IGNORE INTO `cities` (`id`,`city_name`,`metro_id`,`911_website`,`code_website`) VALUES (21,'Lacey',1,NULL,NULL);
