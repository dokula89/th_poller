-- LOCAL DATABASE: review_listings
CREATE TABLE `review_listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `active` varchar(10) NOT NULL DEFAULT 'yes',
  `review_type` varchar(10) NOT NULL DEFAULT '',
  `address_id` varchar(700) NOT NULL DEFAULT '0tt',
  `landlord` varchar(255) NOT NULL,
  `rent` int(11) NOT NULL,
  `repairRating` int(11) NOT NULL,
  `healthSafetyRating` int(11) NOT NULL,
  `rentalStabilityRating` int(11) NOT NULL,
  `tenantPrivacyRating` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `review` varchar(255) NOT NULL,
  `terms-1` varchar(255) NOT NULL,
  `terms-2` varchar(255) NOT NULL,
  `terms-3` varchar(255) NOT NULL,
  `lease_from` varchar(255) NOT NULL DEFAULT '',
  `lease_to` varchar(255) NOT NULL DEFAULT '',
  `place_id` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `review_listings` (`id`,`user_id`,`timestamp`,`active`,`review_type`,`address_id`,`landlord`,`rent`,`repairRating`,`healthSafetyRating`,`rentalStabilityRating`,`tenantPrivacyRating`,`rating`,`review`,`terms-1`,`terms-2`,`terms-3`,`lease_from`,`lease_to`,`place_id`) VALUES (79,0,1753316460,'yes','','644','',500,3,3,3,2,4,'asdasdssss','','','','2025-07-23','','');
INSERT IGNORE INTO `review_listings` (`id`,`user_id`,`timestamp`,`active`,`review_type`,`address_id`,`landlord`,`rent`,`repairRating`,`healthSafetyRating`,`rentalStabilityRating`,`tenantPrivacyRating`,`rating`,`review`,`terms-1`,`terms-2`,`terms-3`,`lease_from`,`lease_to`,`place_id`) VALUES (81,0,1756703762,'yes','','306','',2500,2,2,1,1,3,'It was all terrible','','','','2025-05-04','','306');
INSERT IGNORE INTO `review_listings` (`id`,`user_id`,`timestamp`,`active`,`review_type`,`address_id`,`landlord`,`rent`,`repairRating`,`healthSafetyRating`,`rentalStabilityRating`,`tenantPrivacyRating`,`rating`,`review`,`terms-1`,`terms-2`,`terms-3`,`lease_from`,`lease_to`,`place_id`) VALUES (82,0,1756703846,'yes','','306','',2500,2,2,1,1,3,'It was all terrible','','','','2025-05-04','','306');
INSERT IGNORE INTO `review_listings` (`id`,`user_id`,`timestamp`,`active`,`review_type`,`address_id`,`landlord`,`rent`,`repairRating`,`healthSafetyRating`,`rentalStabilityRating`,`tenantPrivacyRating`,`rating`,`review`,`terms-1`,`terms-2`,`terms-3`,`lease_from`,`lease_to`,`place_id`) VALUES (83,0,1757553591,'yes','','','',500,2,4,3,3,3,'','','','','2025-01-01','','');
INSERT IGNORE INTO `review_listings` (`id`,`user_id`,`timestamp`,`active`,`review_type`,`address_id`,`landlord`,`rent`,`repairRating`,`healthSafetyRating`,`rentalStabilityRating`,`tenantPrivacyRating`,`rating`,`review`,`terms-1`,`terms-2`,`terms-3`,`lease_from`,`lease_to`,`place_id`) VALUES (84,0,1757553610,'yes','','','',500,2,4,3,3,3,'','','','','2025-01-01','','');
