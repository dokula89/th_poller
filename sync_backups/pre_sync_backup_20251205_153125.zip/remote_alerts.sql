-- REMOTE DATABASE: alerts
CREATE TABLE `alerts` (
  `alert_id` int NOT NULL AUTO_INCREMENT,
  `event_id` int DEFAULT NULL,
  `1st_alert` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `2nd_alert` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int NOT NULL,
  `user_id` int NOT NULL,
  `mode_of_del` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `not_frequency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timee` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `what` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `where` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `when` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_much` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `music_genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dance_genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`alert_id`),
  UNIQUE KEY `unique_index` (`user_id`,`alert_id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `alerts` (`alert_id`,`event_id`,`1st_alert`,`2nd_alert`,`time`,`user_id`,`mode_of_del`,`not_frequency`,`timee`,`what`,`where`,`when`,`how_much`,`music_genre`,`dance_genre`) VALUES (177,0,'','',1720593937,4,'email,phone','','','11','109','121','111','110','107');
INSERT IGNORE INTO `alerts` (`alert_id`,`event_id`,`1st_alert`,`2nd_alert`,`time`,`user_id`,`mode_of_del`,`not_frequency`,`timee`,`what`,`where`,`when`,`how_much`,`music_genre`,`dance_genre`) VALUES (178,0,'','',1726377112,4,'email,phone','','','169','165','108','111','','');
