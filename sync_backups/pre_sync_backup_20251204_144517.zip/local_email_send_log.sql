-- LOCAL DATABASE: email_send_log
CREATE TABLE `email_send_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `sent_at` datetime NOT NULL,
  `status` enum('sent','failed','bounced') DEFAULT 'sent',
  `error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_subscriber` (`subscriber_id`),
  KEY `idx_sent_at` (`sent_at`),
  CONSTRAINT `email_send_log_ibfk_1` FOREIGN KEY (`subscriber_id`) REFERENCES `newsletter` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (1,71,'dokula@gmail.com','Update from SeattleListed','2025-11-07 23:35:34','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (2,71,'dokula@gmail.com','Price Changes (Last 24h)','2025-11-07 23:46:36','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (3,71,'dokula@gmail.com','New Listings (Last 24h)','2025-11-07 23:46:45','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (4,71,'dokula@gmail.com','Price Changes (Last 24h)','2025-11-08 20:07:25','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (5,71,'dokula@gmail.com','New Listings (Last 24h)','2025-11-08 20:07:29','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (6,71,'dokula@gmail.com','Price Changes (Last 24h)','2025-11-22 17:43:39','sent',NULL);
INSERT INTO `email_send_log` (`id`,`subscriber_id`,`email`,`subject`,`sent_at`,`status`,`error_message`) VALUES (7,71,'dokula@gmail.com','New Listings (Last 24h)','2025-11-22 17:43:41','sent',NULL);
