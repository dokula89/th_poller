-- REMOTE DATABASE: fcm_tokens
CREATE TABLE `fcm_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `fcm_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `device_info` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_used` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `notifications_enabled` tinyint(1) DEFAULT '1',
  `location_enabled` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_token` (`user_id`,`fcm_token`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_active_tokens` (`is_active`,`user_id`),
  KEY `idx_fcm_token` (`fcm_token`),
  CONSTRAINT `fcm_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fcm_tokens` (`id`,`user_id`,`fcm_token`,`device_type`,`device_info`,`last_used`,`is_active`,`notifications_enabled`,`location_enabled`) VALUES (8,58,'cK5nfmL5hEcyPKhgoDmDt3:APA91bH9CQ1rw4UEMAYfU1SCNnIxcFiy6TNmmCTqGXl5V__L44Nb_9I04i1YYvDHIW1PnWuUrdOKqu57gQx0VsnTbD6YeqlNavbPLrg5KWofgY_hL_C-C4E','web','','2025-11-29 02:15:22',0,1,0);
INSERT INTO `fcm_tokens` (`id`,`user_id`,`fcm_token`,`device_type`,`device_info`,`last_used`,`is_active`,`notifications_enabled`,`location_enabled`) VALUES (9,58,'eUdjqlLyT67hR4mjC2SeDo:APA91bGOqZxcRQQ_QEBYP4L5sJvyAIpQIxsAKVow80j6YLXLnNQuk-mp07061fFYXuTHGXE3jqpBWct9i1rDM5GntGUbbIFDKn_LQmysZpjg3CPhbM7krcQ','web','','2025-11-29 01:34:07',0,1,0);
INSERT INTO `fcm_tokens` (`id`,`user_id`,`fcm_token`,`device_type`,`device_info`,`last_used`,`is_active`,`notifications_enabled`,`location_enabled`) VALUES (10,58,'d-IKVlVt7pmNKOfMUHRR9n:APA91bHMdfX43l6enfHawujV6k0OV8SckRChHmvBXq2BhvH78RjwzpfeC5n53Y7KI40KH0yR76cXDuwCrLVkxfvqcnzEA_PToyFXNIY-7oorLQKjrtVM3BI','web','','2025-11-29 01:34:41',0,1,0);
INSERT INTO `fcm_tokens` (`id`,`user_id`,`fcm_token`,`device_type`,`device_info`,`last_used`,`is_active`,`notifications_enabled`,`location_enabled`) VALUES (11,58,'d-IKVlVt7pmNKOfMUHRR9n:APA91bHLD_WXpPzbfJs__Of5-td_69paq5ng3DNXOOLLAGQSyslAu10HofWRSOB90nzIQRtoSLwL8FCGuIk3SOX4EDdNlbVNR9SBtueWJMZpGiiV-15T2eA','web','','2025-11-29 02:24:16',0,0,0);
INSERT INTO `fcm_tokens` (`id`,`user_id`,`fcm_token`,`device_type`,`device_info`,`last_used`,`is_active`,`notifications_enabled`,`location_enabled`) VALUES (12,58,'d-IKVlVt7pmNKOfMUHRR9n:APA91bHf9O95rpdYIGaQ2wulMY0M4-d2gJ2GKG9k3VYBlIOaAbrVsZrfFiIdzy9o1o1wu7DJW7BCUbipKQ0KnLGqVEWBS4OCtr-6cBdK25jtMeRKeCq8J4g','web','','2025-12-03 16:49:54',1,1,0);
