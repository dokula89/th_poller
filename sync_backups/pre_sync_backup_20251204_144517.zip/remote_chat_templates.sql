-- REMOTE DATABASE: chat_templates
CREATE TABLE `chat_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `display_order` (`display_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (1,'Schedule a Tour','Hi! I''d like to schedule a tour of this property. Are there any times available this week?','🏠',1,1);
INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (2,'Ask About Availability','Hello! Is this unit still available? What is the earliest move-in date?','📅',2,1);
INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (3,'Inquire About Pricing','Hi! I''m interested in this property. Could you provide more details about the pricing and any move-in specials?','💰',3,1);
INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (4,'Ask About Amenities','Hello! I have some questions about the amenities. Are pets allowed? Is parking included?','✨',4,1);
INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (5,'Lease Terms','Hi! Could you tell me about the lease terms? What is the minimum lease duration?','📋',5,1);
INSERT INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`) VALUES (6,'Application Process','Hello! I''d like to know more about the application process and requirements.','📝',6,1);
