-- REMOTE DATABASE: chat_conversations
CREATE TABLE `chat_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `google_addresses_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','closed','archived') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `google_addresses_id` (`google_addresses_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `chat_conversations` (`id`,`google_addresses_id`,`user_id`,`user_name`,`user_email`,`user_phone`,`status`) VALUES (12,990,NULL,'Da Ok','dokula@gmail.com',NULL,'active');
INSERT INTO `chat_conversations` (`id`,`google_addresses_id`,`user_id`,`user_name`,`user_email`,`user_phone`,`status`) VALUES (13,24,58,'Da Ok','dokula@gmail.com',NULL,'active');
INSERT INTO `chat_conversations` (`id`,`google_addresses_id`,`user_id`,`user_name`,`user_email`,`user_phone`,`status`) VALUES (14,879,58,'Da Ok','dokula@gmail.com',NULL,'active');
INSERT INTO `chat_conversations` (`id`,`google_addresses_id`,`user_id`,`user_name`,`user_email`,`user_phone`,`status`) VALUES (15,872,58,'Da Ok','dokula@gmail.com',NULL,'active');
