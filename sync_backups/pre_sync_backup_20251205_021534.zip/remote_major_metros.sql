-- REMOTE DATABASE: major_metros
CREATE TABLE `major_metros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `metro_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `county_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` decimal(9,6) DEFAULT NULL,
  `lng` decimal(9,6) DEFAULT NULL,
  `parcel_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parcel_x_y` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (1,'Seattle','King','47.606200','-122.332100','https://gismaps.kingcounty.gov/parcelviewer2/','517,267','Washington, USA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (2,'Portland','Multnomah','45.505100','-122.675000','https://portlandc.com',NULL,'Oregon, WA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (3,'Bay Area','','37.774900','-122.419400',NULL,NULL,'California, US');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (4,'Sacramento','','38.581600','-121.494400',NULL,NULL,'California, USA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (5,'Los Angeles','Los Angeles',NULL,NULL,NULL,NULL,'California, US');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (6,'San Diego','San Diego',NULL,NULL,NULL,NULL,'California, US');
