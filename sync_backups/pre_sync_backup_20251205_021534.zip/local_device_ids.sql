-- LOCAL DATABASE: device_ids
CREATE TABLE `device_ids` (
  `device_id` varchar(255) DEFAULT NULL,
  `date_inserted` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `last_accessed` int(11) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `device_os` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  UNIQUE KEY `device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('e5c94000b0ed58031fab2782d9fd9632ef51fda14e58586fa3f8e96e2abc036a',1717880918,4,1717881223,'desktop','','172.56.104.85');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('807eb77f6c870f98b1f73da9b3ef10b10a5c54460a2f31b77e6779569e08d6c79e5ce3270447a97b3102c16e0844034cbd0800c837e619d526f4ad13ed7a1866d724699083e390bd3f2083b91bf6da29',1717968076,NULL,NULL,'desktop','','67.168.61.169');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('803782073038e26b6d7712b871c77867f982bbd9e6d4181304b1f460d0a950431a4ef4d284ab800757625f04c24f12ed690a352ce54d3c0078e801333e0ba2ed27448ba76695307a5ef96f5dd88dda0c',1718043385,NULL,NULL,'desktop','','67.168.61.169');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('80baddbfa1d42d36cfcbbd5bdfabb3ff8bb7a524243d9a36429fe37f1c025b861eb4b54212012ef2ef5a03cefa71b216bfddd6e5aa2750001a43429d4b5c365acdbb738b86ffd4af23906975439cee83',1718044011,NULL,NULL,'desktop','','67.168.61.169');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('80d38f28bcd2231e3ccd17390366301e0eb4f571c59bee0f099dba11592c02240d153fffdb3a6db7c4a17d0c68bed03faf00ade338ffc503943e538f54d09573a3537a4adee52356a4367da473d6c3ef',1718044643,NULL,NULL,'desktop','','67.168.61.169');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('80f1791466a4bdfe126f24951daf88d67b4b55cb703fc2922b2c36e4eea090e95a28e85186cf2eda5c517c3063ae49e52d92794e4c1f9500446279b6a6a3cb51db9f9739d0a35acc2f5115f95d35debe',1718469967,NULL,NULL,'desktop','','67.168.61.169');
INSERT IGNORE INTO `device_ids` (`device_id`,`date_inserted`,`user_id`,`last_accessed`,`device_type`,`device_os`,`ip`) VALUES ('80d43d09a034c52606b4a27ad1e0b3b97f976cf314d3e337323ea77d2fbe7cd756e1fded6a1a538723c4cb3ad5a0a733567c8c341b6c21a5f4d0c1e3d0202a7d1347588db0dd0e77a96114e9ca8fc2f2',1718606048,NULL,NULL,'desktop','','67.168.61.169');
