-- LOCAL DATABASE: accounts
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_id` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `reg_type` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(50) DEFAULT '',
  `rememberme` varchar(255) NOT NULL DEFAULT '',
  `role` enum('Member','Admin','Uploader') NOT NULL DEFAULT 'Member',
  `registered` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `reset` varchar(50) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `sms_pin` varchar(4) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `expire_token` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (0,NULL,'Admin','','Daniel','Ok','12321asdasd','','','','Admin',NULL,NULL,'','guest-avatar.png','4256771669',NULL,NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (4,NULL,'dokula','','Daniel','Oku','$2y$10$LyLBt/LvXuWIRYnyujY5vO/CSnY1lgLkIK4R2KoALY.lBawIUdV26','dokulaa@gmail.com','activated','$2y$10$F0bd1rTSt4ZflQRVzIQgb.NIVHd6IAfmffwuudcHHh/xSJ./3zeYG','Admin','2023-10-25 23:02:11','2024-12-31 02:36:28','','','4256771669','',NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (8,NULL,'demo@gmail.com','','','','$2y$10$AmUndq/33gbymj3vKwldpewKZNGiAx/t.bscwxC0gdR1dio5TUAgy','demo@gmail.com','activated','$2y$10$lYRUcmz33uVUan.66bbWyOth11E0qc44YteR6lyiAVfiC4lF7wpMy','Member','2024-10-10 19:59:00','2025-02-18 05:55:40','670890b94de56','guest-avatar.png',NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (56,NULL,'','web_form','asdas','','$2y$10$vxYTuKzq3Uno0BpcdlhWpuF4FmPpXS6QFMlYoHD7MfZVMPsARmKwW','dasd@gmail.com','bbd5f65268e1f9f66053ca45c0a934ba','','Member','2025-07-08 14:00:36',NULL,'','guest-avatar.png',NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (57,NULL,'','web_form','danny','','$2y$10$z6TEBp2WXwmDqNqvqTzRtO6sF9B.5UvSBr2K30Qet5ctk35X0HThK','dokula1@gmail.com','','$2y$10$I1F8vz7e0cgGRTs2kmghBO1g3jKCBJDj7D8kSSwTGPe.ujILOiVcu','Member','2025-07-08 15:05:36','2025-07-13 20:12:27','','',NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (58,'10219855927963608','Da Ok','facebook','','',NULL,'dokula@gmail.com','','','Member','2025-07-12 14:37:13','2025-07-27 16:55:45','','https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=10219855927963608&height=50&width=50&ext=1756252545&hash=AT9h1DYZZ_AZwjABP7zjGmZV',NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `accounts` (`id`,`google_id`,`username`,`reg_type`,`first_name`,`last_name`,`password`,`email`,`activation_code`,`rememberme`,`role`,`registered`,`last_seen`,`reset`,`avatar`,`phone_number`,`sms_pin`,`token`,`expire_token`) VALUES (60,NULL,'','web_form','Daniel Uploader','','$2y$10$IR8nBxVN4vVONt6IHk07u.NZ4tPTU/nk7hEJWKIH8yXGPHf8cVZHu','upload@trustyhousing.com','8fddfbd733ede47d75d337f3b209c529','','Uploader','2025-07-17 19:06:17',NULL,'','guest-avatar.png',NULL,NULL,NULL,NULL);
