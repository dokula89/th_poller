-- LOCAL DATABASE: telegram_messages
CREATE TABLE `telegram_messages` (
  `time_sent` int(11) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  UNIQUE KEY `message` (`message`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

