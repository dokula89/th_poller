-- LOCAL DATABASE: selenium
CREATE TABLE `selenium` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list` varchar(255) NOT NULL DEFAULT 'no',
  `referance` varchar(255) NOT NULL,
  `date_format` varchar(255) DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `last_updated_selenium` varchar(255) DEFAULT NULL,
  `url_size` varchar(255) DEFAULT NULL,
  `url_last_checked` varchar(255) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `enabled` varchar(5) DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `selenium` (`id`,`list`,`referance`,`date_format`,`link`,`last_updated_selenium`,`url_size`,`url_last_checked`,`json`,`enabled`) VALUES (1,'','3','','https://www.climatepledgearena.com/events/list/?tribe-bar-date=2024-04-01&hide_subsequent_recurrence…','1713366960.974484','',NULL,'[{"referance_type":"CLASS_NAME","tag_name":"event-date date-xs-device","attribute":"src","mysql_field":"start"},{"referance_type":"CLASS_NAME","tag_name":"event-title","attribute":"src","mysql_field":"title"},{"referance_type":"Container","tag_name":"event-list","attribute":"div","mysql_field":"none"}]','no');
INSERT IGNORE INTO `selenium` (`id`,`list`,`referance`,`date_format`,`link`,`last_updated_selenium`,`url_size`,`url_last_checked`,`json`,`enabled`) VALUES (2,'','3','F j / gA','https://www.climatepledgearena.com/events/','1713519708.4315689',NULL,NULL,'[{"referance_type":"CLASS_NAME","tag_name":"tribe-events-pro-photo__event-title-link","attribute":"innerText","mysql_field":"title"},{"referance_type":"XPATH","tag_name":"\\/\\/div[@class=''tribe-events-pro-photo__event-details'']\\/\\/div[@class=''event-date'']\\/\\/span[@class=''date'']","attribute":"innerText","mysql_field":"start"},{"referance_type":"CSS_SELECTOR","tag_name":"img.tribe-events-pro-photo__event-featured-image","attribute":"src","mysql_field":"thumb_link"},{"referance_type":"CSS_SELECTOR","tag_name":"a.new_upcoming_events","attribute":"href","mysql_field":"ticket_link"},{"referance_type":"Container","tag_name":"tribe-events-pro-photo","attribute":"div","mysql_field":"none"}]','no');
INSERT IGNORE INTO `selenium` (`id`,`list`,`referance`,`date_format`,`link`,`last_updated_selenium`,`url_size`,`url_last_checked`,`json`,`enabled`) VALUES (3,'2','3',NULL,'https://www.ticketmaster.com',NULL,NULL,NULL,'[{"referance_type":"CSS_SELECTOR","tag_name":"p.is-hidden","attribute":"innerText","mysql_field":"price"},{"referance_type":"Container","tag_name":"rc-slider__label","attribute":"div","mysql_field":"none"}]','no');
INSERT IGNORE INTO `selenium` (`id`,`list`,`referance`,`date_format`,`link`,`last_updated_selenium`,`url_size`,`url_last_checked`,`json`,`enabled`) VALUES (4,'','4',NULL,'https://www.lumenfield.com/events-tickets/event-calendar?category=All+Events&event-venue=Lumen+Field','1713712218.576416',NULL,NULL,'[{"referance_type":"XPATH","tag_name":".\\/\\/div[@class=''cta-block-date-mobile'']\\/\\/div[@class=''cta-block-long-date'']","attribute":"innerText","mysql_field":"start"},{"referance_type":"XPATH","tag_name":".\\/\\/div[@class=''main-title'']\\/\\/h3[@class=''main-title-h3''][1]","attribute":"innerText","mysql_field":"title"},{"referance_type":"XPATH","tag_name":".\\/\\/div[@class=''cta-block-date-mobile'']\\/\\/div[@class=''cta-block-long-time'']","attribute":"innerText","mysql_field":"start_time"},{"referance_type":"Container","tag_name":"db-event-wrap","attribute":"div","mysql_field":"none"}]','yes');
INSERT IGNORE INTO `selenium` (`id`,`list`,`referance`,`date_format`,`link`,`last_updated_selenium`,`url_size`,`url_last_checked`,`json`,`enabled`) VALUES (10,'','923',NULL,'https://seattlelisted.com/user/admin/the_processor/multi-listing-apartments/8-21/cornellandassociates-appfolio.html',NULL,NULL,NULL,NULL,'yes');
