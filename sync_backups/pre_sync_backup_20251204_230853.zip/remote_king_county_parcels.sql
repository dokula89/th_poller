-- REMOTE DATABASE: king_county_parcels
CREATE TABLE `king_county_parcels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `time_inserted` int DEFAULT NULL,
  `parcel_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Present_use` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Property_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Jurisdiction` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'SEATTLE',
  `Taxpayer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Appraised_value` decimal(15,2) DEFAULT NULL,
  `Lot_area` decimal(15,2) DEFAULT NULL,
  `num_of_units` int DEFAULT NULL,
  `num_of_buildings` int DEFAULT NULL,
  `Levy_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_addresses_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parcel_number` (`parcel_number`),
  KEY `google_addresses_id` (`google_addresses_id`),
  CONSTRAINT `king_county_parcels_ibfk_1` FOREIGN KEY (`google_addresses_id`) REFERENCES `google_addresses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

