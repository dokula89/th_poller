-- LOCAL DATABASE: network_daily_stats
CREATE TABLE `network_daily_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `price_changes` int(11) DEFAULT 0,
  `apartments_added` int(11) DEFAULT 0,
  `apartments_subtracted` int(11) DEFAULT 0,
  `total_listings` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_network_date` (`network_id`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (1,1,'2025-11-04',9,3,4,191,'2025-11-04 23:03:05');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (2,4,'2025-11-05',0,0,0,18,'2025-11-05 18:39:44');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (6,1,'2025-11-07',9,0,0,191,'2025-11-07 19:44:46');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (7,4,'2025-11-07',0,0,0,18,'2025-11-07 19:45:09');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (9,1,'2025-11-08',16,16,13,194,'2025-11-08 18:30:37');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (10,4,'2025-11-08',0,4,2,20,'2025-11-08 18:30:51');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (11,2,'2025-11-08',1,38,0,39,'2025-11-08 18:57:11');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (12,7,'2025-11-08',0,24,0,24,'2025-11-08 19:13:41');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (13,5,'2025-11-08',0,21,0,21,'2025-11-08 19:22:36');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (21,6,'2025-11-08',0,0,0,30,'2025-11-08 23:16:20');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (25,6,'2025-11-10',0,0,0,30,'2025-11-10 01:36:46');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (26,5,'2025-11-10',0,3,2,21,'2025-11-10 01:37:18');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (27,2,'2025-11-10',2,0,0,39,'2025-11-10 01:38:16');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (28,4,'2025-11-10',0,0,0,19,'2025-11-10 01:38:57');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (29,1,'2025-11-10',16,0,0,186,'2025-11-10 01:39:32');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (39,7,'2025-11-10',0,0,0,24,'2025-11-10 22:33:36');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (42,1,'2025-11-11',1,190,0,191,'2025-11-11 17:15:52');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (43,5,'2025-11-11',0,22,0,22,'2025-11-11 17:17:49');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (46,6,'2025-11-11',0,30,0,30,'2025-11-11 17:43:35');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (47,2,'2025-11-11',1,38,0,39,'2025-11-11 17:54:09');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (48,7,'2025-11-11',1,23,0,24,'2025-11-11 17:55:32');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (49,4,'2025-11-11',0,17,0,17,'2025-11-11 17:55:42');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (50,1,'2025-11-14',4,2,8,185,'2025-11-14 05:19:17');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (51,2,'2025-11-14',1,0,1,38,'2025-11-14 05:22:32');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (52,4,'2025-11-14',0,1,1,17,'2025-11-14 05:23:55');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (53,4,'2025-11-15',0,0,1,16,'2025-11-15 18:44:33');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (54,4,'2025-11-22',7,0,0,21,'2025-11-22 03:07:32');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (64,2,'2025-11-22',12,3,4,45,'2025-11-22 03:54:34');
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`,`created_at`) VALUES (65,1,'2025-11-22',29,0,0,173,'2025-11-22 03:57:35');
