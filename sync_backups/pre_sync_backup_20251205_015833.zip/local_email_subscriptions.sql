-- LOCAL DATABASE: email_subscriptions
CREATE TABLE `email_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `unsubscribed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `email_subscriptions` (`id`,`email`,`subscribed_at`,`is_active`,`unsubscribed_at`) VALUES (1,'dokula@gmail.com','2025-12-05 01:29:21',1,NULL);
INSERT IGNORE INTO `email_subscriptions` (`id`,`email`,`subscribed_at`,`is_active`,`unsubscribed_at`) VALUES (2,'dokula1@gmail.com','2025-12-05 01:29:21',1,NULL);
