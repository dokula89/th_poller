-- LOCAL DATABASE: login_attempts
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `attempts_left` tinyint(1) NOT NULL DEFAULT 5,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=735 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT IGNORE INTO `login_attempts` (`id`,`ip_address`,`attempts_left`,`date`,`type`) VALUES (725,'149.154.161.201',5,'2025-12-05 01:29:21',NULL);
INSERT IGNORE INTO `login_attempts` (`id`,`ip_address`,`attempts_left`,`date`,`type`) VALUES (731,'45.135.232.10',5,'2025-12-05 01:29:21',NULL);
INSERT IGNORE INTO `login_attempts` (`id`,`ip_address`,`attempts_left`,`date`,`type`) VALUES (732,'20.171.207.16',5,'2025-12-05 01:29:21','reset_pass_form');
INSERT IGNORE INTO `login_attempts` (`id`,`ip_address`,`attempts_left`,`date`,`type`) VALUES (733,'149.154.161.246',5,'2025-12-05 01:29:21','reset_pass_form');
INSERT IGNORE INTO `login_attempts` (`id`,`ip_address`,`attempts_left`,`date`,`type`) VALUES (734,'185.216.231.86',5,'2025-12-05 01:29:21',NULL);
