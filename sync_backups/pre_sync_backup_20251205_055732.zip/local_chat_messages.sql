-- LOCAL DATABASE: chat_messages
CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `sender_type` enum('user','property_manager','system') NOT NULL,
  `message` text NOT NULL,
  `attachment_url` varchar(500) DEFAULT NULL,
  `attachment_type` enum('image','pdf','document') DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `created_at` (`created_at`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `fk_messages_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (24,12,NULL,'user','Hi! I''d like to schedule a tour of this property. Are there any times available this week?',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (25,12,NULL,'user','Hi! I''d like to schedule a tour of this property. Are there any times available this week?',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (26,13,NULL,'user','Hi! I''d like to schedule a tour of this property. Are there any times available this week?',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (27,14,58,'user','Hi! I''d like to schedule a tour of this property. Are there any times available this week?',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (28,14,NULL,'user','helloaa',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (29,15,58,'user','Hi! I''d like to schedule a tour of this property. Are there any times available this week?',NULL,NULL,0,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_messages` (`id`,`conversation_id`,`sender_id`,`sender_type`,`message`,`attachment_url`,`attachment_type`,`is_read`,`created_at`) VALUES (30,15,NULL,'user','did it send',NULL,NULL,0,'2025-12-05 05:56:58');
