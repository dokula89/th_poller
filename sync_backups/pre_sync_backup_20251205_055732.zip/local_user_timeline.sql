-- LOCAL DATABASE: user_timeline
CREATE TABLE `user_timeline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `move_in` date NOT NULL,
  `move_out` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `user_timeline` (`id`,`user_id`,`address`,`move_in`,`move_out`,`created_at`,`updated_at`) VALUES (1,0,'16636 36th ln S','2025-07-01','2025-07-31','2025-12-05 05:56:58','2025-12-05 05:56:58');
