-- LOCAL DATABASE: chat_templates
CREATE TABLE `chat_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `display_order` (`display_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (1,'Schedule a Tour','Hi! I''d like to schedule a tour of this property. Are there any times available this week?','🏠',1,1,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (2,'Ask About Availability','Hello! Is this unit still available? What is the earliest move-in date?','📅',2,1,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (3,'Inquire About Pricing','Hi! I''m interested in this property. Could you provide more details about the pricing and any move-in specials?','💰',3,1,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (4,'Ask About Amenities','Hello! I have some questions about the amenities. Are pets allowed? Is parking included?','✨',4,1,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (5,'Lease Terms','Hi! Could you tell me about the lease terms? What is the minimum lease duration?','📋',5,1,'2025-12-05 05:56:58');
INSERT IGNORE INTO `chat_templates` (`id`,`title`,`message`,`icon`,`display_order`,`is_active`,`created_at`) VALUES (6,'Application Process','Hello! I''d like to know more about the application process and requirements.','📝',6,1,'2025-12-05 05:56:58');
