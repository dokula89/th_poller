-- LOCAL DATABASE: upload_data
CREATE TABLE `upload_data` (
  `default_img` varchar(1000) NOT NULL,
  `external_links` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `FILE_NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `upload_data` (`default_img`,`external_links`,`id`,`user_id`,`event_id`,`FILE_NAME`) VALUES ('8182640android-launchericon-96-96-ev-4.png','',17,4,822,'');
