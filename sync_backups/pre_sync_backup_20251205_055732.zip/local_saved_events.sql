-- LOCAL DATABASE: saved_events
CREATE TABLE `saved_events` (
  `user_id` varchar(50) NOT NULL,
  `table_id` varchar(200) NOT NULL,
  `table` varchar(200) NOT NULL,
  `time_saved` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  UNIQUE KEY `unique_index` (`user_id`,`table_id`),
  KEY `event_id` (`table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('0','','apartment_listings',1741671766,'149.154.161.219');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('0','2184','apartment_listings',1742002739,'50.125.18.211');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('0','2195','apartment_listings',1741671764,'50.106.1.84');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('0','2737','apartment_listings',1742893521,'157.97.134.142');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('46','1276','apartment_listings',1740963686,'185.216.231.99');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('46','944','apartment_listings',1740959623,'185.216.231.99');
INSERT IGNORE INTO `saved_events` (`user_id`,`table_id`,`table`,`time_saved`,`ip`) VALUES ('46','946','apartment_listings',1740959650,'185.216.231.99');
