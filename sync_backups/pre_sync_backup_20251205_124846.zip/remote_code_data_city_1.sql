-- REMOTE DATABASE: code_data_city_1
CREATE TABLE `code_data_city_1` (
  `RecordNum` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `RecordType` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RecordTypeMapped` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RecordTypeDesc` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Description` text COLLATE utf8mb4_unicode_ci,
  `OpenDate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LastInspDate` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LastInspResult` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `StatusCurrent` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OriginalAddress1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OriginalCity` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OriginalState` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OriginalZip` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Link` text COLLATE utf8mb4_unicode_ci,
  `Latitude` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Location1` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`RecordNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

