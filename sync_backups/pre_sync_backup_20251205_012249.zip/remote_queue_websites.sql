-- REMOTE DATABASE: queue_websites
CREATE TABLE `queue_websites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `the_css` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `capture_mode` enum('headless','browser') COLLATE utf8mb4_unicode_ci DEFAULT 'headless',
  `status` enum('queued','running','done','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'queued',
  `type` enum('Networks','Websites','Parcel','Code','911') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` tinyint unsigned NOT NULL DEFAULT '5',
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `source_table` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` bigint DEFAULT NULL,
  `output_json_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `processed_at` datetime DEFAULT NULL,
  `run_interval_minutes` int DEFAULT '4320',
  `steps` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `listing_id` int DEFAULT NULL,
  `click_x` int DEFAULT NULL COMMENT 'X coordinate for right-click position',
  `click_y` int DEFAULT NULL COMMENT 'Y coordinate for right-click position',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_source_table_id` (`source_table`,`source_id`),
  KEY `idx_status_priority_id` (`status`,`priority`,`id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `queue_websites_chk_1` CHECK (json_valid(`steps`))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (1,'https://cornellandassociates.appfolio.com/listings','listings js-listings-container','headless','done','Networks',5,114,'No internet connection available. Please check your network and try again.','networks',1,'C:\\Users\\DanielOkula\\Desktop\\Captures\\apartment_listings.json','2025-11-11 17:38:21',4320,NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (2,'https://incitypropertyholdings.appfolio.com/listings','listings js-listings-container','headless','done','Networks',5,14,'No listings found in JSON','networks',2,'C:\\Users\\dokul\\Desktop\\robot\\th_poller\\Captures\\apartment_listings.json','2025-11-11 17:56:25',4320,NULL,NULL,NULL,NULL);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (4,'https://milestoneproperties.appfolio.com/listings','js-listings-container','headless','done','Networks',4,16,'cannot access local variable ''datetime'' where it is not associated with a value','networks',4,'C:\\Users\\DanielOkula\\Desktop\\robot\\th_poller\\Captures\\apartment_listings.json','2025-11-11 17:57:02',4320,'1',NULL,NULL,NULL);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (5,'https://www.206pm.com/availability','"all-listings','browser','done','Networks',5,32,'User cancelled coordinate input','networks',5,'C:\\Users\\DanielOkula\\Desktop\\Captures\\apartment_listings.json','2025-11-11 17:42:00',4320,NULL,NULL,954,560);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (6,'https://www.rentmilestone.com/properties','GPmm8Z"','browser','done','Networks',5,51,'No full_address found in any listing - cannot proceed','networks',6,'C:\\Users\\DanielOkula\\Desktop\\robot\\th_poller\\Captures\\apartment_listings.json','2025-11-10 18:34:36',4320,NULL,NULL,812,560);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (7,'https://www.peaklivingps.com/listings','"all-listings','browser','done','Networks',5,11,'Automatic capture failed: Yellow highlight not found in screenshot. Cannot continue automation.','networks',7,'C:\\Users\\dokul\\Desktop\\robot\\th_poller\\Captures\\apartment_listings.json','2025-11-11 17:57:20',4320,NULL,NULL,949,542);
INSERT IGNORE INTO `queue_websites` (`id`,`link`,`the_css`,`capture_mode`,`status`,`type`,`priority`,`attempts`,`last_error`,`source_table`,`source_id`,`output_json_path`,`processed_at`,`run_interval_minutes`,`steps`,`listing_id`,`click_x`,`click_y`) VALUES (43,'https://gismaps.kingcounty.gov/parcelviewer2/','king_county_parcels','browser','queued','Parcel',5,0,NULL,'king_county_parcels',217,NULL,NULL,4320,NULL,NULL,NULL,NULL);
