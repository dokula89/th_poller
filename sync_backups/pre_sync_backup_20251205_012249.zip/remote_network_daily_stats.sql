-- REMOTE DATABASE: network_daily_stats
CREATE TABLE `network_daily_stats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `network_id` int NOT NULL,
  `date` date NOT NULL,
  `price_changes` int DEFAULT '0',
  `apartments_added` int DEFAULT '0',
  `apartments_subtracted` int DEFAULT '0',
  `total_listings` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_network_date` (`network_id`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (1,1,'2025-11-04',9,3,4,191);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (2,4,'2025-11-05',0,0,0,18);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (6,1,'2025-11-07',9,0,0,191);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (7,4,'2025-11-07',0,0,0,18);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (9,1,'2025-11-08',16,16,13,194);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (10,4,'2025-11-08',0,4,2,20);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (11,2,'2025-11-08',1,38,0,39);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (12,7,'2025-11-08',0,24,0,24);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (13,5,'2025-11-08',0,21,0,21);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (21,6,'2025-11-08',0,0,0,30);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (25,6,'2025-11-10',0,0,0,30);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (26,5,'2025-11-10',0,3,2,21);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (27,2,'2025-11-10',2,0,0,39);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (28,4,'2025-11-10',0,0,0,19);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (29,1,'2025-11-10',16,0,0,186);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (39,7,'2025-11-10',0,0,0,24);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (42,1,'2025-11-11',1,190,0,191);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (43,5,'2025-11-11',0,22,0,22);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (46,6,'2025-11-11',0,30,0,30);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (47,2,'2025-11-11',1,38,0,39);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (48,7,'2025-11-11',1,23,0,24);
INSERT IGNORE INTO `network_daily_stats` (`id`,`network_id`,`date`,`price_changes`,`apartments_added`,`apartments_subtracted`,`total_listings`) VALUES (49,4,'2025-11-11',0,17,0,17);
