-- LOCAL DATABASE: form_submit_stopper
CREATE TABLE `form_submit_stopper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website_section` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `form_submit_stopper` (`id`,`website_section`,`time`,`ip`,`user_id`) VALUES (1,'as',1719001486,'67.168.61.169',4);
INSERT IGNORE INTO `form_submit_stopper` (`id`,`website_section`,`time`,`ip`,`user_id`) VALUES (2,'invite_friends',1719001537,'67.168.61.169',4);
