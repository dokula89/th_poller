-- LOCAL DATABASE: roommate_listings
CREATE TABLE `roommate_listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `profile_pictures` varchar(255) NOT NULL,
  `first_name` varbinary(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL,
  `active` varchar(255) NOT NULL DEFAULT 'yes',
  `dob` varchar(255) NOT NULL DEFAULT '',
  `available_date` varchar(255) NOT NULL,
  `price_max` int(11) NOT NULL,
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `sex` varchar(255) NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  `HobbiesText` varchar(255) NOT NULL,
  `PetsText` varchar(255) NOT NULL,
  `accessibilityText` varchar(255) NOT NULL,
  `budgetText` varchar(255) NOT NULL,
  `scentsText` varchar(255) NOT NULL,
  `lightText` varchar(255) NOT NULL,
  `disabilityText` varchar(255) NOT NULL,
  `extraLaborText` varchar(255) NOT NULL,
  `neuroDivergantText` varchar(255) NOT NULL,
  `noiseLevelText` varchar(255) NOT NULL,
  `sharedText` varchar(255) NOT NULL,
  `numResidentsText` varchar(255) NOT NULL,
  `cleanlinessText` varchar(255) NOT NULL,
  `zodiacText` varchar(255) NOT NULL,
  `drugUsageText` varchar(255) NOT NULL,
  `dietText` varchar(255) NOT NULL,
  `parkingText` varchar(255) NOT NULL,
  `transportText` varchar(255) NOT NULL,
  `choresText` varchar(255) NOT NULL,
  `sharedBathroomText` varchar(255) NOT NULL,
  `covidConcernsText` varchar(255) NOT NULL,
  `allergiesText` varchar(255) NOT NULL,
  `kidsText` varchar(255) NOT NULL,
  `moveinDate` varchar(255) NOT NULL,
  `leaseLength` varchar(255) NOT NULL,
  `suburbs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`suburbs`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (2,496,'[]',X'','','Roommate Listing','yes','','',0,'','','','female','1742769282','[]','asd3wdasdasd','','','','','','Age range: 2 - 3454','','','','','','','','','','','','','','','','','','null');
INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (3,496,'["3_0.png","3_1.png","3_2.png"]',X'','','Roommate Listing','yes','','',0,'','','','female','1742769373','[]','asd3wdasdasd','','','','','','Age range: 2 - 3454','','','','','','','','','','','','','','','','','','null');
INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (4,496,'["4_0.png"]',X'','','Roommate Listing','yes','','',0,'','','','no_preference','1742770590','[]','','','','','','','Age range: 18 - 80','','','','','','','','','','','','','','','','','','null');
INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (5,496,'["5_0.png"]',X'','','Roommate Listing','yes','','',0,'','','','no_preference','1742771202','[]','','','','','','','Age range: 18 - 80','','','','','','','','','','','','','','','','','','[]');
INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (6,496,'[]',X'','','Roommate Listing','yes','','',0,'','','','no_preference','1742771446','[]','','','','','','','Age range: 18 - 80','','','','','','','','','','','','','','','','','','["capitol_hill", "fremont", "downtown", "queen_anne"]');
INSERT IGNORE INTO `roommate_listings` (`id`,`user_id`,`profile_pictures`,`first_name`,`last_name`,`name`,`active`,`dob`,`available_date`,`price_max`,`city`,`state`,`avatar`,`sex`,`timestamp`,`HobbiesText`,`PetsText`,`accessibilityText`,`budgetText`,`scentsText`,`lightText`,`disabilityText`,`extraLaborText`,`neuroDivergantText`,`noiseLevelText`,`sharedText`,`numResidentsText`,`cleanlinessText`,`zodiacText`,`drugUsageText`,`dietText`,`parkingText`,`transportText`,`choresText`,`sharedBathroomText`,`covidConcernsText`,`allergiesText`,`kidsText`,`moveinDate`,`leaseLength`,`suburbs`) VALUES (7,1,'["7_0.png"]',X'','','Roommate Listing','yes','','',0,'','','','male','1742859465','[]','','','','','','','Age range: 25 - 80','','','','','','','','','','','','','','','','','','["capitol_hill", "queen_anne"]');
