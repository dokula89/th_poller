-- LOCAL DATABASE: networks
CREATE TABLE `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `web_type` varchar(250) NOT NULL,
  `active` varchar(250) NOT NULL DEFAULT 'yes',
  `name` varchar(250) NOT NULL,
  `link` varchar(250) NOT NULL,
  `major_metro_id` int(11) NOT NULL,
  `details_base` varchar(250) NOT NULL,
  `the_css` varchar(250) NOT NULL,
  `listing_processing_id` varchar(250) NOT NULL,
  `details_processing_id` varchar(250) NOT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `first_x` int(11) DEFAULT NULL,
  `first_y` int(11) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `major_metro_id` (`major_metro_id`),
  CONSTRAINT `networks_ibfk_1` FOREIGN KEY (`major_metro_id`) REFERENCES `major_metros` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (1,'Appfolio','','CornellAssociates','https://cornellandassociates.appfolio.com/listings',1,'https://cornellandassociates.appfolio.com','js-listings-container','2','',556,405,424,130,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (2,'Appfolio','','inCityInc','https://www.incityinc.com/managed-properties/residential-vacancies',1,'https://incitypropertyholdings.appfolio.com','listings js-listings-container','','',594,586,473,263,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (3,'Appfolio','no','ShowMojo','https://showmojo.com/97140fb06f/l',1,'https://showmojo.com','listings js-listings','','',1090,709,NULL,NULL,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (4,'Appfolio','','MilestoneProperties','https://milestoneproperties.appfolio.com/listings',1,'https://milestoneproperties.appfolio.com','js-listings-container','2','',629,546,535,272,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (5,'square','','206pm','https://www.206pm.com/availability',1,'https://www.206pm.com','all-listings','','',895,682,765,404,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (6,'square','','RentMilestone','https://www.rentmilestone.com/properties',1,'','GPmm8Z"','','',726,583,616,308,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (7,'square','','PeakLiving','https://www.peaklivingps.com/listings',1,'https://www.peaklivingps.com','all-listings','','',992,725,883,516,NULL);
INSERT IGNORE INTO `networks` (`id`,`web_type`,`active`,`name`,`link`,`major_metro_id`,`details_base`,`the_css`,`listing_processing_id`,`details_processing_id`,`x`,`y`,`first_x`,`first_y`,`error_message`) VALUES (8,'Appfolio','yes','Bode','https://livingbode.com/available-units2',1,'','','','',NULL,NULL,NULL,NULL,NULL);
