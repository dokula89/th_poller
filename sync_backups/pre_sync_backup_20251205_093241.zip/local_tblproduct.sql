-- LOCAL DATABASE: tblproduct
CREATE TABLE `tblproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (1,'Washington Round Sticker','3DcAM01','product-images/1.png',4.0);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (2,'Pride with Rainbow Colors Sticker','USB02','product-images/2.png',3.5);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (3,'Large Love Sticker','wristWear03','product-images/3.png',4.0);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (4,'Rainbow Smiley Face Sticker','LPN45','product-images/4.png',3.5);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (5,'Rainbow Sunglasses Sticker','44ffs','product-images/5.png',4.0);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (6,'Rainbow LGBTQ Sticker','g66hd','product-images/6.png',4.0);
INSERT IGNORE INTO `tblproduct` (`id`,`name`,`code`,`image`,`price`) VALUES (7,'Rainbow Queer Sticker','45gggfss','product-images/7.png',4.0);
