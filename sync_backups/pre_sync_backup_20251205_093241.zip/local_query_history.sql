-- LOCAL DATABASE: query_history
CREATE TABLE `query_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (1,'seelct');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (2,'select * from `events`');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (3,'');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (4,'');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (5,'select * from `events` where id = ''1558''');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (6,'select * from `events` where id =');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (7,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (8,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (9,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (10,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (11,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (12,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (13,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (14,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (15,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (16,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (17,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (18,'select * from `events` where id = 1558');
INSERT IGNORE INTO `query_history` (`id`,`text`) VALUES (19,'select * from `events` where id = 1558');
