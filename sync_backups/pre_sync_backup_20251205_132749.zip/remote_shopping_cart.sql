-- REMOTE DATABASE: shopping_cart
CREATE TABLE `shopping_cart` (
  `id` tinyint NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_added` int NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `shopping_cart_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `tblproduct` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (20,2,'4',1719995950,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (21,1,'4',1719996265,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (25,1,'0',1720001334,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (26,2,'4',1720222346,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (27,3,'4',1720222381,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (28,1,'0',1720222846,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (29,1,'0',1720443621,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (30,3,'0',1720443906,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (31,4,'0',1720443909,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (33,1,'8',1729760452,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (34,1,'8',1729760460,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (35,1,'8',1729760464,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (36,1,'m1e0pilv3vja46t6re70e72uts',1729865562,1);
INSERT IGNORE INTO `shopping_cart` (`id`,`item_id`,`user_id`,`time_added`,`quantity`) VALUES (37,7,'fhl85u0sn6ug0kib6cjgv12rf8',1733058133,1);
