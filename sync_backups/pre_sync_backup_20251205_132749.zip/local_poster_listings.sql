-- LOCAL DATABASE: poster_listings
CREATE TABLE `poster_listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `time_submitted` int(11) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `bedrooms` int(11) NOT NULL,
  `bathrooms` int(11) NOT NULL,
  `rent` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `poster_listings` (`id`,`user_id`,`time_submitted`,`address`,`email`,`name`,`phone`,`bedrooms`,`bathrooms`,`rent`) VALUES (55,0,1742939205,'ChIJ8c3otvoLlVQRryu4OfyK8JA','dokula@gmail.com','','4256771669',1,1,1);
INSERT IGNORE INTO `poster_listings` (`id`,`user_id`,`time_submitted`,`address`,`email`,`name`,`phone`,`bedrooms`,`bathrooms`,`rent`) VALUES (56,0,1742939285,'ChIJ8c3otvoLlVQRryu4OfyK8JA','dokula@gmail.com','','4256771669',1,1,1);
INSERT IGNORE INTO `poster_listings` (`id`,`user_id`,`time_submitted`,`address`,`email`,`name`,`phone`,`bedrooms`,`bathrooms`,`rent`) VALUES (57,0,1742939305,'ChIJ8c3otvoLlVQRryu4OfyK8JA','dokula@gmail.com','','4256771669',1,1,1);
INSERT IGNORE INTO `poster_listings` (`id`,`user_id`,`time_submitted`,`address`,`email`,`name`,`phone`,`bedrooms`,`bathrooms`,`rent`) VALUES (58,0,1742943106,'ChIJ2V8omBoVkFQR-GwoQmEAsPQ','dokula@gmail.com','','4256772669',1,2,1);
INSERT IGNORE INTO `poster_listings` (`id`,`user_id`,`time_submitted`,`address`,`email`,`name`,`phone`,`bedrooms`,`bathrooms`,`rent`) VALUES (59,0,1742943663,'EikyNDU5IEF1cm9yYSBBdmUgTiwgU2VhdHRsZSwgV0EgOTgxMDksIFVTQSIxEi8KFAoSCWfSh58aFZBUEcUmCGAyYtEIEJsTKhQKEglfv2ikfRCQVBFpo6ZGJECP6g','','','4256771669',1,2,2);
