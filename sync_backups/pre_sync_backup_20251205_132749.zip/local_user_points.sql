-- LOCAL DATABASE: user_points
CREATE TABLE `user_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (1,'review',0,1742197442,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (2,'review',496,1742776907,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (3,'review',0,1742776908,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (4,'review',496,1742776912,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (5,'review',496,1742776935,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (6,'review',496,1742776950,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (7,'review',496,1742777027,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (8,'review',496,1742777034,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (9,'review',496,1742777103,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (10,'review',496,1742777230,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (11,'review',496,1742777235,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (12,'review',496,1742777292,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (13,'review',496,1742777312,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (14,'review',496,1742792705,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (15,'review',496,1742793564,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (16,'review',496,1742793628,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (17,'review',496,1742793661,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (18,'review',496,1742793752,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (19,'review',496,1742793782,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (20,'review',496,1742793925,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (21,'review',496,1742794052,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (22,'review',496,1742794113,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (23,'review',496,1742794238,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (24,'review',496,1742794668,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (25,'review',496,1742794812,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (26,'review',0,1742885247,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (27,'review',0,1743033118,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (28,'review',0,1743034419,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (29,'review',0,1743034652,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (30,'review',0,1743034700,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (31,'review',0,1743034723,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (32,'review',0,1743034855,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (33,'review',0,1743034908,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (34,'review',0,1743035363,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (35,'review',0,1743035544,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (36,'review',0,1743035591,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (37,'review',0,1743035681,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (38,'review',0,1743035722,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (39,'review',0,1743035777,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (40,'review',0,1743036731,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (41,'review',0,1743036735,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (42,'review',0,1749265316,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (43,'review',0,1749265317,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (44,'review',0,1753315698,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (45,'review',0,1753315924,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (46,'review',0,1753316015,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (47,'review',0,1753316148,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (48,'review',0,1753316460,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (49,'review',0,1753661752,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (50,'review',0,1756703762,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (51,'review',0,1756703846,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (52,'review',0,1757553591,2);
INSERT IGNORE INTO `user_points` (`id`,`action`,`user_id`,`time`,`value`) VALUES (53,'review',0,1757553610,2);
