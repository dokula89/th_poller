-- LOCAL DATABASE: major_metros
CREATE TABLE `major_metros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metro_name` varchar(255) NOT NULL,
  `county_name` varchar(255) NOT NULL,
  `lat` decimal(9,6) DEFAULT NULL,
  `lng` decimal(9,6) DEFAULT NULL,
  `parcel_link` varchar(255) DEFAULT NULL,
  `parcel_x_y` varchar(50) DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (1,'Seattle','King','47.606200','-122.332100','https://gismaps.kingcounty.gov/parcelviewer2/',NULL,'Washington, USA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (2,'Portland','Multnomah','45.505100','-122.675000','https://portlandc.com',NULL,'Oregon, WA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (3,'Bay Area','','37.774900','-122.419400',NULL,NULL,'California, US');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (4,'Sacramento','','38.581600','-121.494400',NULL,NULL,'California, USA');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (5,'Los Angeles','Los Angeles',NULL,NULL,NULL,NULL,'California, US');
INSERT IGNORE INTO `major_metros` (`id`,`metro_name`,`county_name`,`lat`,`lng`,`parcel_link`,`parcel_x_y`,`state`) VALUES (6,'San Diego','San Diego',NULL,NULL,NULL,NULL,'California, US');
