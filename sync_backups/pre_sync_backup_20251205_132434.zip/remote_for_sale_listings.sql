-- REMOTE DATABASE: for_sale_listings
CREATE TABLE `for_sale_listings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bedrooms` int NOT NULL,
  `bathrooms` int NOT NULL,
  `sqft` int DEFAULT '0',
  `user_id` int NOT NULL,
  `timestamp` int NOT NULL,
  `image_urls` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `for_sale_listings` (`id`,`price`,`address`,`bedrooms`,`bathrooms`,`sqft`,`user_id`,`timestamp`,`image_urls`) VALUES (7,34567,'ChIJ8c3otvoLlVQRryu4OfyK8JA',1,1,NULL,496,1742712505,'["7_0.png","7_1.png","7_2.png"]');
INSERT IGNORE INTO `for_sale_listings` (`id`,`price`,`address`,`bedrooms`,`bathrooms`,`sqft`,`user_id`,`timestamp`,`image_urls`) VALUES (13,234500,'Eic1NiBOVyBNYXJrZXQgU3QsIFNlYXR0bGUsIFdBIDk4MTAzLCBVU0EiMBIuChQKEglD-HnYshWQVBH5pJDvtUYNkxA4KhQKEglfrFPBxxWQVBFR4mudG6lDuw',2,2,NULL,0,1742858579,'["13_0.webp"]');
